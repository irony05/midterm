import React from 'react';
import ShopProductForm from './ShopProductForm';

function App() {
  return (
    <div className="App">
      <ShopProductForm />
      
    </div>
  );
}

export default App;
